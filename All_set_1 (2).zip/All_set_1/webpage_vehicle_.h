#pragma once
const char PAGE_HTML[] =
R"HTML(
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ESP32 Car Control</title>
<style>
  body{ background:#0c1222; color:white; font-family:sans-serif; }
  button{ width:100%; height:60px; margin:6px 0; font-size:20px; }
</style>
</head>
<body>

<h2>ESP32 Mecanum Car</h2>

<div>
  <p>RPM: <span id="rpmTxt">80</span></p>
  <input id="rpm" type="range" min="0" max="200" value="80">
</div>

<div>
  <button onclick="send('forward')">Forward</button>
  <button onclick="send('back')">Backward</button>
  <button onclick="send('left')">Left</button>
  <button onclick="send('right')">Right</button>
  <button onclick="send('cw')">Rotate CW</button>
  <button onclick="send('ccw')">Rotate CCW</button>
  <button onclick="send('stop')">STOP</button>
</div>

<script>
const BASE = window.location.origin;    // ⭐自动使用 ESP32 当前 IP

let rpm = 80;
document.getElementById("rpm").oninput = e=>{
  rpm = Number(e.target.value);
  document.getElementById("rpmTxt").innerText = rpm;
  send(lastMode);
};

let lastMode = "stop";

function send(mode){
  lastMode = mode;
  fetch(`${BASE}/cmd?mode=${mode}&rpm=${rpm}`)
    .catch(()=>console.log("send failed"));
}
</script>

</body>
</html>
)HTML";
