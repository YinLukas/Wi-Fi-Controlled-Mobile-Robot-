#pragma once
#include "vive510.h"

void initVives();
void updateVives();

extern uint16_t vive1_x, vive1_y;
extern uint16_t vive2_x, vive2_y;